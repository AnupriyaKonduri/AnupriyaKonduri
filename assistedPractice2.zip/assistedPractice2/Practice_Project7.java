package assistedPractice2;

	import java.io.File;
	import java.io.FileWriter;
	import java.io.FileReader;
	import java.io.BufferedReader;
	import java.io.BufferedWriter;
	import java.io.IOException;
	
	public class Practice_Project7 
	{
	    public static void main(String[] args) 
	    {
	       
	        String filePath = "java_practice_questions.txt";
	        createFile(filePath);
	        readFile(filePath);
	        updateFile(filePath, "Updated content");
	        readFile(filePath);
	        deleteFile(filePath);
	    }

	    // Create operation
	    private static void createFile(String filePath) 
	    {
	        try 
	        {
	            File file = new File(filePath);
	            if (file.createNewFile()) 
	            {
	                System.out.println("File created: " + file.getName());
	            } else 
	            {
	                System.out.println("File already exists.");
	            }
	        } 
	        catch (IOException e) 
	        {
	            System.out.println("An error occurred during file creation.");
	            e.printStackTrace();
	        }
	    }

	    // Read operation
	    private static void readFile(String filePath) 
	    {
	        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) 
	        {
	            String line;
	            System.out.println("Reading file content:");
	            while ((line = reader.readLine()) != null) 
	            {
	                System.out.println(line);
	            }
	        } 
	        catch (IOException e) 
	        {
	            System.out.println("An error occurred during file reading.");
	            e.printStackTrace();
	        }
	    }

	    // Update operation
	    private static void updateFile(String filePath, String content) 
	    {
	        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath)))
	        {
	            writer.write(content);
	            System.out.println("File updated.");
	        } 
	        catch (IOException e) 
	        {
	            System.out.println("An error occurred during file update.");
	            e.printStackTrace();
	        }
	    }

	    // Delete operation
	    private static void deleteFile(String filePath) 
	    {
	        File file = new File(filePath);

	        if (file.delete()) 
	        {
	            System.out.println("File deleted: " + file.getName());
	        } 
	        else
	        {
	            System.out.println("Failed to delete the file.");
	        }
	    }
	}