package assistedPractice2;

import java.util.Scanner;

public class Practice_Project4
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter two number");
		int num1=s.nextInt();
		int num2=s.nextInt();
		
		try
		{
			int result=num1/num2;
			System.out.println("The result is:"+result);
		}
		catch(ArithmeticException ae)
		{
			System.out.println("Enter num2 a valid number other than 0");
		}
	}

}
