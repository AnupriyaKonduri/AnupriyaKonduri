package assistedPractice2;

import java.util.Scanner;

class Practice_Practice5 
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the age:");
		int age=s.nextInt();
		while(true)
		{
			try
			{
				toValidateAge(age);
				break;
			}
			catch(Exception e)
			{
				System.out.println("Enter your age again:");
				age=s.nextInt();
			}
			finally
			{
				System.out.println("End of the programme");
			}
		}
	}
	
	public static void toValidateAge(int age) throws AgeIsTooYoungException,AgeIsTooOldException
	{
		if(age>=18&&age<=60)
		{
			System.out.println("Resume accepted");
		}
		else if(age<18)
		{
			throw new AgeIsTooYoungException();
		}
		else
		{
			throw new AgeIsTooOldException();
		}
	}
}