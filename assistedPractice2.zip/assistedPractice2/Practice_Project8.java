package assistedPractice2;

class Encapsulation 
{
	    private String accountHolder;
	    private double balance;
	    public Encapsulation(String accountHolder, double initialBalance)
	    {
	        this.accountHolder = accountHolder;
	        if (initialBalance>=0) 
	        {
	            this.balance = initialBalance;
	        } 
	        else 
	        {
	            System.out.println("Invalid initial balance. Setting balance to 0.");
	            this.balance=0;
	        }
	    }
	    public String getAccountHolder() 
	    {
	        return accountHolder;
	    }
	    public double getBalance() 
	    {
	        return balance;
	    }
	    public void deposit(double amount)
	    {
	        if (amount>0) 
	        {
	            this.balance=balance+amount;
	            System.out.println("Deposit of" + amount + " successful. New balance:" + balance);
	        } 
	        else 
	        {
	            System.out.println("Invalid deposit amount. Please enter a positive value.");
	        }
	    }
	    public void withdraw(double amount) 
	    {
	        if (amount>0&&amount<=balance)
	        {
	            this.balance=balance-amount;
	            System.out.println("Withdrawal of" + amount + " successful. New balance:" + balance);
	        } 
	        else 
	        {
	            System.out.println("Invalid withdrawal amount or insufficient funds.");
	        }
	    }
	}

	class Practice_Project8 
	{
	    public static void main(String[] args) 
	    {
	    	Encapsulation account = new Encapsulation("Mahesh Babu", 1000.0);
	        System.out.println("Account Holder:" + account.getAccountHolder());
	        System.out.println("Initial Balance:" + account.getBalance());
	        account.deposit(500.0);
	        account.withdraw(200.0);
	        account.withdraw(1500.0);
	        System.out.println("Final Balance:" + account.getBalance());
	    }
	}