package assistedPractice2;

public class AgeIsTooOldException extends Exception{

}
