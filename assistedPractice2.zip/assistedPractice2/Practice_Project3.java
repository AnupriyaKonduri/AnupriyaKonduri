package assistedPractice2;

class Synchronization 
{
    public  synchronized void increment()
    {
        for (int i=0; i<3; i++) 
        {
            System.out.println(Thread.currentThread().getName() );
            try 
            {
            	Thread.sleep(1000);
            } 
            catch (InterruptedException e) 
            {
                e.printStackTrace();
            }
        }
    }
}

class MyThread1 extends Thread 
{
    private Synchronization sharedResource;

    public MyThread1(Synchronization sharedResource, String name) 
    {
        super(name);
        this.sharedResource = sharedResource;
    }
    public void run() 
    {
        sharedResource.increment();
    }
}

public class Practice_Project3
{
    public static void main(String[] args)
    {
    	Synchronization sync = new Synchronization();
    	
        Thread thread1 = new MyThread1(sync, "Thread-1");
        Thread thread2 = new MyThread1(sync, "Thread-2");
        Thread thread3 = new MyThread1(sync, "Thread-3");

        thread1.start();
        thread2.start();
        thread3.start();
    }
}

