package assistedPractice2;

//My class implements Runnable interface
class Practice_Project2 implements Runnable 
{
    public void run() 
    {
        for (int i=1;i<=5; i++) 
        {
            System.out.println("Runnable executing: " + i);
            try 
            {
                Thread.sleep(1000);
                
            } 
            catch (InterruptedException e) 
            {
                e.printStackTrace();
            }
        }
    }
}

class Main1 
{
    public static void main(String[] args) 
    {
    	Practice_Project2 pp2 = new Practice_Project2();
        Thread myThread = new Thread(pp2);
        myThread.start();
    }
}
