package assistedPractice2;

public class AgeIsTooYoungException extends Exception {

}
